const express = require('express');
const Redis = require('ioredis');
const path = require('path');

const app = express();
const redis = new Redis({
    host: 'redis', // Mengarah ke nama service 'redis' di docker-compose.yml
    port: 6379
});

app.use(express.json());

// Simulasi Database Rekam Medis Pusat Rumah Sakit (Lambat karena enkripsi & I/O berat)
const getPatientMedicalRecordFromDB = () => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                id_pasien: "PASIEN-9921",
                nama: "Budi Santoso",
                kondisi: "Kritis (Gagal Jantung)",
                golongan_darah: "AB+",
                alergi_obat: ["Penicillin", "Ibuprofen"],
                tindakan_darurat: "Berikan Epinephrine 1mg, siapkan Defibrillator.",
                timestamp_diperbarui: new Date().toLocaleTimeString()
            });
        }, 2000); // Simulasi delay 2 detik
    });
};

// Endpoint API Tarik Data Rekam Medis Pasien
app.get('/api/data', async (req, res) => {
    const cacheKey = 'pasien:kritis:9921';

    try {
        // 1. Periksa ketersediaan data di dalam RAM Redis
        const cachedMedicalRecord = await redis.get(cacheKey);

        if (cachedMedicalRecord) {
            // JIKA DATA DITEMUKAN (CACHE HIT)
            return res.json({
                source: 'Redis Core RAM (Cache Hit)',
                data: JSON.parse(cachedMedicalRecord)
            });
        }

        // 2. JIKA DATA TIDAK ADA (CACHE MISS) -> Terpaksa hubungi database pusat yang lambat
        const freshMedicalRecord = await getPatientMedicalRecordFromDB();

        // 3. Gandakan data ke Redis dengan TTL 15 Detik untuk keamanan akses berikutnya
        await redis.set(cacheKey, JSON.stringify(freshMedicalRecord), 'EX', 15);

        return res.json({
            source: 'Database Pusat RS (Cache Miss)',
            data: freshMedicalRecord
        });

    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

// Endpoint untuk Reset Sesi / Menghapus Paksa Cache oleh Admin Medis
app.post('/api/data/invalidate', async (req, res) => {
    try {
        await redis.del('pasien:kritis:9921');
        res.json({ message: 'Sesi Cache Jaringan Medis berhasil dibersihkan!' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Menyediakan halaman entry utama UGD Terminal Dashboard
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(3000, () => {
    console.log('Server UGD Data Core aktif di http://localhost:3000');
});